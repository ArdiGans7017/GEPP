import { Speaker } from "../types";
import { Twitter, Linkedin, Github, UserCircle } from "lucide-react";

interface SpeakerCardProps {
  key?: string;
  speaker: Speaker;
  onSelectEventWithSpeaker?: (speakerId: string) => void;
}

export default function SpeakerCard({ speaker, onSelectEventWithSpeaker }: SpeakerCardProps) {
  return (
    <div
      id={`speaker-card-${speaker.id}`}
      className="group relative flex flex-col justify-between overflow-hidden rounded-[32px] border border-white/50 bg-white/60 backdrop-blur-xl p-6 shadow-sm transition-all duration-300 hover:shadow-xl hover:bg-white/80 select-none"
    >
      {/* Absolute coral corner spotlight */}
      <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-[#ff6f61]/5 to-transparent rounded-bl-full pointer-events-none" />

      <div>
        {/* Header containing Speaker photo + credentials */}
        <div className="flex items-start gap-4 mb-4">
          <img
            src={speaker.avatar}
            alt={speaker.name}
            referrerPolicy="no-referrer"
            className="w-16 h-16 rounded-2xl object-cover ring-2 ring-indigo-50 shadow-inner group-hover:scale-105 transition-transform duration-300"
          />
          <div className="flex-1">
            <h4 className="font-display font-bold text-lg text-indigo-950 group-hover:text-indigo-900 transition-colors">
              {speaker.name}
            </h4>
            <p className="text-xs font-semibold text-[#ff6f61]">{speaker.title}</p>
            <p className="text-xs text-indigo-900/50 font-medium">{speaker.company}</p>
          </div>
        </div>

        {/* Short Bio */}
        <p className="text-sm text-indigo-900/70 leading-relaxed mb-5 line-clamp-3">
          {speaker.bio}
        </p>
      </div>

      {/* Social Icons Footer */}
      <div className="flex items-center justify-between border-t border-indigo-50 pt-4 mt-auto">
        <div className="flex items-center gap-3">
          {speaker.twitter && (
            <a
              href={`https://twitter.com/${speaker.twitter}`}
              target="_blank"
              rel="noopener noreferrer"
              title="Twitter Profile"
              className="text-indigo-900/40 hover:text-[#ff6f61] transition-colors"
              onClick={(e) => e.stopPropagation()}
            >
              <Twitter className="w-4 h-4" />
            </a>
          )}
          {speaker.linkedin && (
            <a
              href={`https://linkedin.com/in/${speaker.linkedin}`}
              target="_blank"
              rel="noopener noreferrer"
              title="LinkedIn Profile"
              className="text-indigo-900/40 hover:text-indigo-600 transition-colors"
              onClick={(e) => e.stopPropagation()}
            >
              <Linkedin className="w-4 h-4" />
            </a>
          )}
          {speaker.github && (
            <a
              href={`https://github.com/${speaker.github}`}
              target="_blank"
              rel="noopener noreferrer"
              title="GitHub Repository"
              className="text-indigo-900/40 hover:text-indigo-950 transition-colors"
              onClick={(e) => e.stopPropagation()}
            >
              <Github className="w-4 h-4" />
            </a>
          )}
        </div>

        {onSelectEventWithSpeaker && (
          <button
            onClick={() => onSelectEventWithSpeaker(speaker.id)}
            className="text-xs font-semibold text-indigo-600 hover:text-[#ff6f61] flex items-center gap-1 transition-colors"
          >
            <UserCircle className="w-3.5 h-3.5" />
            <span>View Sessions</span>
          </button>
        )}
      </div>
    </div>
  );
}
