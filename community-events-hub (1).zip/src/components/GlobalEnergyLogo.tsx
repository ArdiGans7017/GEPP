import React from "react";

interface GlobalEnergyLogoProps {
  className?: string;
  showText?: boolean;
  size?: "sm" | "md" | "lg" | "xl";
  layout?: "horizontal" | "vertical";
}

export const GlobalEnergyLogo: React.FC<GlobalEnergyLogoProps> = ({
  className = "",
  showText = true,
  size = "md",
  layout = "vertical"
}) => {
  // Determine dimensions based on size
  const logoDimensions = {
    sm: { width: 44, height: 44, textClass: "text-sm", subTextClass: "text-[7.5px]" },
    md: { width: 80, height: 80, textClass: "text-lg", subTextClass: "text-[10px]" },
    lg: { width: 140, height: 140, textClass: "text-2xl", subTextClass: "text-xs" },
    xl: { width: 240, height: 240, textClass: "text-4xl", subTextClass: "text-sm" }
  };

  const { width, height } = logoDimensions[size];
  const isHorizontal = layout === "horizontal";

  return (
    <div
      className={`flex ${
        isHorizontal ? "flex-row items-center gap-2.5 text-left" : "flex-col items-center text-center"
      } select-none ${className}`}
      id="global-energy-logo-container"
    >
      {/* SVG Emblem Illustration representing the reference image perfectly */}
      <svg
        width={width}
        height={height}
        viewBox="0 0 500 500"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="drop-shadow-md animate-fade-in shrink-0"
        id="global-energy-emblem"
      >
        <defs>
          {/* Gold gradients for pristine metallic feel */}
          <linearGradient id="heavyGoldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFF2B2" />
            <stop offset="30%" stopColor="#D4AF37" />
            <stop offset="70%" stopColor="#AA7C11" />
            <stop offset="100%" stopColor="#C5A039" />
          </linearGradient>

          <linearGradient id="softGoldGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#F9D976" />
            <stop offset="100%" stopColor="#E9B646" />
          </linearGradient>

          {/* Oceans / sky blue-to-indigo gradient */}
          <linearGradient id="oceanGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#4FA0E2" />
            <stop offset="50%" stopColor="#2A6496" />
            <stop offset="100%" stopColor="#122F54" />
          </linearGradient>

          {/* Crescent Metallic Dark Indigo/Blue gradient */}
          <linearGradient id="crescentBlueGrad" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#0B1A30" />
            <stop offset="50%" stopColor="#183654" />
            <stop offset="100%" stopColor="#08101C" />
          </linearGradient>

          {/* Bright yellow sunrays glow */}
          <radialGradient id="sunGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFEAA7" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#F9D976" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* 1. RISING SUN RAYS (Crown of energy at the top) */}
        <g id="sun-rays" className="opacity-95">
          {/* Central sun halo background */}
          <circle cx="250" cy="180" r="100" fill="url(#sunGlow)" />
          
          {/* Detailed individual pointed rays radiating upwards */}
          {/* Paths drawn symmetrically to form the stunning ray crown */}
          <path d="M 250 160 L 250 20 L 260 160 Z" fill="url(#heavyGoldGrad)" />
          <path d="M 235 162 L 210 30 L 245 162 Z" fill="url(#heavyGoldGrad)" />
          <path d="M 265 162 L 290 30 L 255 162 Z" fill="url(#heavyGoldGrad)" />
          
          <path d="M 220 168 L 170 50 L 230 165 Z" fill="url(#heavyGoldGrad)" />
          <path d="M 280 168 L 330 50 L 270 165 Z" fill="url(#heavyGoldGrad)" />
          
          <path d="M 205 178 L 130 80 L 212 173 Z" fill="url(#heavyGoldGrad)" />
          <path d="M 295 178 L 370 80 L 288 173 Z" fill="url(#heavyGoldGrad)" />

          <path d="M 190 190 L 95 120 L 198 185 Z" fill="url(#heavyGoldGrad)" />
          <path d="M 310 190 L 405 120 L 302 185 Z" fill="url(#heavyGoldGrad)" />
          
          <path d="M 180 205 L 70 170 L 185 200 Z" fill="url(#heavyGoldGrad)" />
          <path d="M 320 205 L 430 170 L 315 200 Z" fill="url(#heavyGoldGrad)" />
        </g>

        {/* 2. MAIN GLOBE BACKGROUND (Blue ocean, gold continents) */}
        <g id="globe">
          {/* Base Ocean Circle centered at (250, 240) */}
          <circle cx="250" cy="240" r="140" fill="url(#oceanGrad)" stroke="#AA7C11" strokeWidth="2" />

          {/* Continent Landmass shapes clipped to the globe circle */}
          <g clipPath="url(#globe-clip)">
            <clipPath id="globe-clip">
              <circle cx="250" cy="240" r="140" />
            </clipPath>

            {/* Stylized high-quality continent shapes */}
            {/* North America & Greenland */}
            <path
              d="M 130 170 C 135 150 150 135 170 135 C 195 135 205 150 190 175 C 180 190 195 210 180 220 C 165 230 150 220 145 200 C 140 185 125 180 130 170 Z"
              fill="url(#softGoldGrad)"
              opacity="0.9"
            />
            <path
              d="M 210 120 C 230 115 250 130 240 145 C 230 160 215 150 205 140 C 200 130 205 125 210 120 Z"
              fill="url(#softGoldGrad)"
              opacity="0.95"
            />
            {/* Europe / Asia */}
            <path
              d="M 250 150 C 270 130 300 120 330 125 C 360 130 380 160 370 180 C 360 200 380 220 360 240 C 340 260 310 240 290 230 C 270 220 260 200 250 180 Z"
              fill="url(#softGoldGrad)"
              opacity="0.9"
            />
            {/* South America */}
            <path
              d="M 180 245 C 190 240 210 255 205 270 C 200 285 220 310 210 330 C 200 350 180 370 175 360 C 170 350 165 320 170 300 C 175 280 170 255 180 245 Z"
              fill="url(#softGoldGrad)"
              opacity="0.9"
            />
            {/* Africa */}
            <path
              d="M 255 235 C 275 220 305 220 320 240 C 330 255 320 280 315 300 C 310 320 295 340 280 345 C 270 350 260 330 265 315 C 270 300 250 290 250 270 C 250 250 245 240 255 235 Z"
              fill="url(#softGoldGrad)"
              opacity="0.9"
            />
            {/* Southeast Asia & Australia */}
            <path
              d="M 335 260 L 345 265 L 340 275 Z M 350 280 L 360 285 L 355 295 Z"
              fill="url(#softGoldGrad)"
            />
            <path
              d="M 350 310 C 365 310 385 320 380 340 C 375 360 350 365 340 350 C 330 335 340 310 350 310 Z"
              fill="url(#softGoldGrad)"
              opacity="0.9"
            />
          </g>
        </g>

        {/* 3. INDUSTRIAL ENERGY TOWER SILHOUETTES AT THE CENTER */}
        {/* Crisp refinery structures: chimneys, cooling towers, fractional columns */}
        <g id="energy-refinery-towers" fill="#111111" stroke="#AA7C11" strokeWidth="0.75" className="drop-shadow-sm">
          {/* Main Column Left */}
          <rect x="200" y="195" width="12" height="75" rx="1.5" />
          <line x1="200" y1="210" x2="212" y2="210" stroke="#FFEAA7" strokeWidth="0.5" />
          <line x1="200" y1="230" x2="212" y2="230" stroke="#FFEAA7" strokeWidth="0.5" />
          <line x1="200" y1="250" x2="212" y2="250" stroke="#FFEAA7" strokeWidth="0.5" />
          {/* Domed Column Center Big */}
          <rect x="238" y="140" width="24" height="135" rx="4" />
          {/* Cap details on the column */}
          <path d="M 238 145 L 262 145" stroke="#FFEAA7" strokeWidth="1" />
          <path d="M 238 170 L 262 170" stroke="#FFEAA7" strokeWidth="1" />
          <path d="M 238 195 L 262 195" stroke="#FFEAA7" strokeWidth="1" />
          <path d="M 238 220 L 262 220" stroke="#FFEAA7" strokeWidth="1" />
          <path d="M 238 245 L 262 245" stroke="#FFEAA7" strokeWidth="1" />
          {/* Antennas / Piping lines on core tower */}
          <line x1="250" y1="140" x2="250" y2="105" stroke="#111111" strokeWidth="4" />
          <line x1="250" y1="105" x2="250" y2="90" stroke="#D4AF37" strokeWidth="1.5" />
          <circle cx="250" cy="90" r="3" fill="#ff6f61" />

          {/* Medium Column Left-Center */}
          <rect x="220" y="170" width="14" height="100" rx="2" />
          <line x1="220" y1="190" x2="234" y2="190" stroke="#FFEAA7" strokeWidth="0.5" />
          <line x1="220" y1="215" x2="234" y2="215" stroke="#FFEAA7" strokeWidth="0.5" />
          <line x1="220" y1="240" x2="234" y2="240" stroke="#FFEAA7" strokeWidth="0.5" />

          {/* Tall Refinery Column Right */}
          <rect x="268" y="160" width="16" height="115" rx="3" />
          <line x1="268" y1="185" x2="284" y2="185" stroke="#FFEAA7" strokeWidth="0.8" />
          <line x1="268" y1="210" x2="284" y2="210" stroke="#FFEAA7" strokeWidth="0.8" />
          <line x1="268" y1="235" x2="284" y2="235" stroke="#FFEAA7" strokeWidth="0.8" />
          <line x1="276" y1="160" x2="276" y2="120" stroke="#111111" strokeWidth="3" />
          {/* Flame flare element representing active Energy */}
          <path d="M 276 118 C 274 110 270 112 276 95 C 282 112 278 110 276 118 Z" fill="#ff6f61" />

          {/* Spherical gas storage tank auxiliary */}
          <circle cx="180" cy="255" r="16" />
          {/* Support legs */}
          <line x1="168" y1="255" x2="168" y2="275" stroke="#111111" strokeWidth="2" />
          <line x1="180" y1="255" x2="180" y2="275" stroke="#111111" strokeWidth="2" />
          <line x1="192" y1="255" x2="192" y2="275" stroke="#111111" strokeWidth="2" />

          {/* Smaller Storage Tank Right */}
          <path d="M 293 220 L 311 220 L 311 270 L 293 270 Z" rx="2" />
          <path d="M 293 220 C 293 214 311 214 311 220 Z" />
          
          {/* Pipes connecting elements */}
          <path d="M 212 250 L 220 250" stroke="#111111" strokeWidth="3" fill="none" />
          <path d="M 234 230 L 238 230" stroke="#111111" strokeWidth="3" fill="none" />
          <path d="M 262 210 L 268 210" stroke="#111111" strokeWidth="3" fill="none" />
          <path d="M 284 250 L 293 250" stroke="#111111" strokeWidth="3" fill="none" />
        </g>

        {/* 4. CRESCENT SWOOSHES (The elegant sweeping gold and blue bottom framing wings) */}
        <g id="bottom-swooshes">
          {/* Base shadow ellipse for 3D realism */}
          <ellipse cx="250" cy="425" rx="170" ry="12" fill="#000000" opacity="0.15" filter="blur(8px)" />

          {/* Deep Turquoise / Indigo Main Crescent Ring */}
          <path
            d="M 110 210 C 105 280 140 375 250 415 C 360 375 395 280 390 210 C 420 280 380 394 250 422 C 120 394 80 280 110 210 Z"
            fill="url(#crescentBlueGrad)"
            stroke="#122F54"
            strokeWidth="1"
            className="drop-shadow-md"
          />

          {/* Golden Upper Sweeping Ring */}
          <path
            d="M 85 240 C 90 325 155 405 250 405 C 345 405 410 325 415 240 C 430 330 350 425 250 425 C 150 425 70 330 85 240 Z"
            fill="url(#heavyGoldGrad)"
          />

          {/* Sharp dynamic swoosh accent lines (left & right wings) */}
          <path
            d="M 95 210 C 130 330 250 370 250 370 C 250 370 150 330 110 240 Z"
            fill="url(#heavyGoldGrad)"
            opacity="0.8"
          />
          <path
            d="M 405 210 C 370 330 250 370 250 370 C 250 370 350 330 390 240 Z"
            fill="url(#heavyGoldGrad)"
            opacity="0.8"
          />
        </g>
      </svg>

      {/* 5. TYPOGRAPHY (Rendered cleanly using React/Tailwind elements) */}
      {showText && (
        <div 
          className={`${isHorizontal ? "mt-0 flex flex-col items-start text-left" : "mt-4 flex flex-col items-center text-center"} select-none`} 
          id="global-energy-text-brand"
        >
          <div className={`flex items-center ${isHorizontal ? "justify-start" : "justify-center"} font-serif leading-none tracking-wide`}>
            <span className={`${logoDimensions[size].textClass} font-extrabold text-slate-800 uppercase`}>
              GLOBAL&nbsp;
            </span>
            <span
              className={`${logoDimensions[size].textClass} font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-[#D4AF37] to-[#AA7C11] uppercase`}
            >
              ENERGY
            </span>
          </div>
          
          {/* Subtext with the decorative lines on both sides as in reference */}
          <div className={`flex items-center ${isHorizontal ? "justify-start" : "justify-center"} gap-1 mt-1 w-full`}>
            {!isHorizontal && <div className="h-[1px] w-6 bg-slate-400/50"></div>}
            <span
              className={`${logoDimensions[size].subTextClass} font-sans font-bold text-slate-500 tracking-[0.2em] uppercase whitespace-nowrap`}
            >
              PROJECT PROFESSIONAL
            </span>
            {!isHorizontal && <div className="h-[1px] w-6 bg-slate-400/50"></div>}
          </div>
        </div>
      )}
    </div>
  );
};
