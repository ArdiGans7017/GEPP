import React, { useState, useEffect } from "react";
import { Event } from "../types";
import { Calendar, MapPin, Users, ArrowUpRight, AlarmClock } from "lucide-react";

interface EventCardProps {
  key?: string;
  event: Event;
  isRegistered: boolean;
  onSelect: (event: Event) => void;
  onQuickRSVP: (eventId: string, e: React.MouseEvent) => void;
}

export default function EventCard({
  event,
  isRegistered,
  onSelect,
  onQuickRSVP
}: EventCardProps) {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
    isOver: false
  });

  // Countdown calculations
  useEffect(() => {
    const calculateTimeLeft = () => {
      const eventDateTime = new Date(`${event.date}T${event.time}:00`);
      const now = new Date();
      const difference = eventDateTime.getTime() - now.getTime();

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0, isOver: true });
        return;
      }

      setTimeLeft({
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
        isOver: false
      });
    };

    calculateTimeLeft();
    const interval = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(interval);
  }, [event.date, event.time]);

  // Formatted date string for humans
  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr);
    return d.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric"
    });
  };

  const categoryColorMap: Record<string, { bg: string, text: string, dot: string }> = {
    Tech: { bg: "bg-indigo-50", text: "text-indigo-600", dot: "bg-indigo-500" },
    Design: { bg: "bg-rose-50", text: "text-rose-600", dot: "bg-rose-500" },
    Product: { bg: "bg-amber-50", text: "text-amber-600", dot: "bg-amber-500" },
    Marketing: { bg: "bg-emerald-50", text: "text-emerald-600", dot: "bg-emerald-500" },
    Wellness: { bg: "bg-teal-50", text: "text-teal-600", dot: "bg-teal-500" },
    Social: { bg: "bg-purple-50", text: "text-purple-600", dot: "bg-purple-500" }
  };

  const scheme = categoryColorMap[event.category] || { bg: "bg-gray-100", text: "text-gray-700", dot: "bg-gray-500" };

  return (
    <div
      id={`event-card-${event.id}`}
      onClick={() => onSelect(event)}
      className="group relative cursor-pointer flex flex-col justify-between h-full overflow-hidden rounded-[32px] transition-all duration-300 hover:-translate-y-2 select-none border border-white/50 shadow-sm hover:shadow-xl bg-white/60 hover:bg-white/80 backdrop-blur-xl"
    >
      {/* Dynamic Cover Accent Gradient */}
      <div className={`h-2.5 w-full bg-gradient-to-r ${event.coverGradient}`} />

      {/* Main card body */}
      <div className="p-6 flex flex-col flex-grow justify-between gap-6">
        <div>
          {/* Top category & indicators */}
          <div className="flex items-center justify-between mb-4">
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold gap-1.5 ${scheme.bg} ${scheme.text}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${scheme.dot}`} />
              {event.category}
            </span>

            {isRegistered ? (
              <span className="text-xs font-bold text-teal-600 bg-teal-50 px-2.5 py-1 rounded-full flex items-center gap-1 animate-pulse border border-teal-200">
                ✓ RSVP'd
              </span>
            ) : null}
          </div>

          {/* Event Title */}
          <h3 className="font-display font-bold text-xl text-indigo-950 mb-3 group-hover:text-[#ff6f61] transition-colors duration-200 line-clamp-2">
            {event.title}
          </h3>

          {/* Time and location details */}
          <div className="space-y-2 text-sm text-indigo-900/70 mb-5">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-500" />
              <span>{formatDate(event.date)} at {event.time}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#ff6f61]" />
              <span className="truncate">{event.location}</span>
            </div>
          </div>

          {/* Countdown Clock (Show live countdown or 'Ongoing/Completed') */}
          <div className="mb-5 p-3.5 rounded-2xl bg-white/40 border border-white/50 backdrop-blur-md">
            <div className="flex items-center gap-1.5 mb-1.5 text-xs font-medium text-indigo-900/50">
              <AlarmClock className="w-3.5 h-3.5 text-[#ff6f61] shrink-0" />
              <span>COUNTDOWN TIMER:</span>
            </div>

            {timeLeft.isOver ? (
              <div className="text-xs font-semibold text-rose-500 uppercase tracking-widest mt-1">
                📢 Session Started or Completed
              </div>
            ) : (
              <div className="grid grid-cols-4 gap-1 text-center font-display">
                <div className="bg-white/50 px-1.5 py-0.5 rounded-lg border border-white/40 backdrop-blur-sm">
                  <div className="text-md font-bold text-indigo-950 leading-none">{String(timeLeft.days).padStart(2, "0")}</div>
                  <div className="text-[9px] uppercase tracking-wider text-indigo-900/50 font-sans mt-0.5">days</div>
                </div>
                <div className="bg-white/50 px-1.5 py-0.5 rounded-lg border border-white/40 backdrop-blur-sm">
                  <div className="text-md font-bold text-indigo-950 leading-none">{String(timeLeft.hours).padStart(2, "0")}</div>
                  <div className="text-[9px] uppercase tracking-wider text-indigo-900/50 font-sans mt-0.5">hrs</div>
                </div>
                <div className="bg-white/50 px-1.5 py-0.5 rounded-lg border border-white/40 backdrop-blur-sm">
                  <div className="text-md font-bold text-indigo-950 leading-none">{String(timeLeft.minutes).padStart(2, "0")}</div>
                  <div className="text-[9px] uppercase tracking-wider text-indigo-900/50 font-sans mt-0.5">mins</div>
                </div>
                <div className="bg-[#fff5f5]/60 px-1.5 py-0.5 rounded-lg border border-[#ffe3e0] backdrop-blur-sm">
                  <div className="text-md font-bold text-rose-500 leading-none">{String(timeLeft.seconds).padStart(2, "0")}</div>
                  <div className="text-[9px] uppercase tracking-wider text-rose-500/60 font-sans mt-0.5">secs</div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer controls & Speaker info */}
        <div>
          <div className="flex items-center justify-between border-t border-indigo-50 pt-4 mt-auto">
            {/* Speaker info */}
            <div className="flex items-center gap-2.5">
              {event.coSpeaker ? (
                <div className="flex items-center">
                  <img
                    src={event.speaker.avatar}
                    alt={event.speaker.name}
                    referrerPolicy="no-referrer"
                    className="w-9 h-9 rounded-full object-cover ring-2 ring-white z-10 shrink-0"
                  />
                  <img
                    src={event.coSpeaker.avatar}
                    alt={event.coSpeaker.name}
                    referrerPolicy="no-referrer"
                    className="w-9 h-9 rounded-full object-cover ring-2 ring-white -ml-3 shrink-0"
                  />
                  <div className="text-xs leading-none ml-2">
                    <p className="font-semibold text-indigo-950 truncate max-w-[85px]" title={`${event.speaker.name} & ${event.coSpeaker.name}`}>
                      {event.speaker.name.split(" ")[1] || event.speaker.name} & {event.coSpeaker.name.split(" ")[1] || event.coSpeaker.name}
                    </p>
                    <p className="text-indigo-900/50 text-[10px] truncate max-w-[85px]">2 Speakers</p>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2.5">
                  <img
                    src={event.speaker.avatar}
                    alt={event.speaker.name}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-100"
                  />
                  <div className="text-xs leading-normal">
                    <p className="font-semibold text-indigo-950 truncate max-w-[110px]">{event.speaker.name}</p>
                    <p className="text-indigo-900/50 text-[10px] truncate max-w-[110px]">{event.speaker.title}</p>
                  </div>
                </div>
              )}
            </div>

            {/* Quick RSVP or View Details indicator */}
            <button
              id={`rsvp-btn-${event.id}`}
              onClick={(e) => {
                e.stopPropagation();
                onQuickRSVP(event.id, e);
              }}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all duration-200 shadow-sm ${
                isRegistered
                  ? "bg-slate-100 text-slate-500 border border-slate-200 cursor-default"
                  : "bg-[#ff6f61] hover:bg-[#ff5747] text-white hover:shadow-md hover:-translate-y-0.5 active:translate-y-0"
              }`}
            >
              <span>{isRegistered ? "Going" : "RSVP"}</span>
              {!isRegistered && <ArrowUpRight className="w-3.5 h-3.5 shrink-0" />}
            </button>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-indigo-900/40 mt-3 font-medium">
            <Users className="w-3.5 h-3.5" />
            <span>{event.rsvpCount} community members attending</span>
          </div>
        </div>
      </div>
    </div>
  );
}
