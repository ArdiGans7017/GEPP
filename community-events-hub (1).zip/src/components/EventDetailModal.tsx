import React, { useState } from "react";
import { Event, Comment, UserProfile } from "../types";
import { X, Calendar, MapPin, Users, Send, ArrowUpRight, MessageSquare, ShieldCheck, Mail } from "lucide-react";

interface EventDetailModalProps {
  event: Event;
  isRegistered: boolean;
  currentUser: UserProfile;
  onClose: () => void;
  onRSVP: (eventId: string) => void;
  onCancelRSVP: (eventId: string) => void;
  onAddComment: (eventId: string, comment: Comment) => void;
}

export default function EventDetailModal({
  event,
  isRegistered,
  currentUser,
  onClose,
  onRSVP,
  onCancelRSVP,
  onAddComment,
}: EventDetailModalProps) {
  const [commentText, setCommentText] = useState("");

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim()) return;

    const newComment: Comment = {
      id: `comm-${Date.now()}`,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatar,
      authorTitle: `${currentUser.title} @ ${currentUser.company}`,
      content: commentText.trim(),
      timestamp: "Just now"
    };

    onAddComment(event.id, newComment);
    setCommentText("");
  };

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr);
    return d.toLocaleDateString("en-US", {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric"
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto bg-indigo-950/40 backdrop-blur-md animate-fade-in">
      {/* Container Card */}
      <div
        id="event-detail-modal"
        className="relative w-full max-w-3xl overflow-hidden bg-white/70 backdrop-blur-2xl rounded-[32px] shadow-2xl border border-white/50 max-h-[90vh] flex flex-col"
      >
        {/* Banner with Event Title */}
        <div className={`relative p-8 text-white bg-gradient-to-r ${event.coverGradient} shrink-0`}>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2.5 rounded-full bg-black/20 hover:bg-black/40 text-white transition-colors border border-white/20"
            title="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>

          <span className="inline-block px-3 py-1 text-xs font-bold uppercase tracking-widest bg-white/20 backdrop-blur-md rounded-full mb-3">
            {event.category}
          </span>
          <h2 className="font-display font-extrabold text-2xl md:text-3xl tracking-tight max-w-[90%] mb-4">
            {event.title}
          </h2>

          <div className="flex flex-wrap items-center gap-y-2 gap-x-6 text-sm text-white/90">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-[#ff6f61]" />
              <span>{formatDate(event.date)} at {event.time}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-[#ff6f61]" />
              <span>{event.location}</span>
            </div>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-6 md:p-8 overflow-y-auto space-y-8 flex-grow">
          
          {/* Action Row: RSVP controls */}
          <div className="flex flex-col sm:flex-row items-center justify-between p-5 bg-white/40 backdrop-blur-md rounded-2xl border border-white/50 gap-4">
            <div className="flex items-center gap-3.5 text-indigo-950">
              <span className="p-3 bg-white/50 rounded-2xl border border-white/50 flex items-center justify-center">
                <Users className="w-6 h-6 text-[#ff6f61]" />
              </span>
              <div>
                <p className="font-bold text-lg leading-tight">{event.rsvpCount} Attending</p>
                <p className="text-xs text-indigo-950/50 font-medium">Capacity: {event.capacity || "Unlimited"} spots</p>
              </div>
            </div>

            <div className="w-full sm:w-auto flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
              {event.registrationLink && (
                <a
                  href={event.registrationLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 text-center text-sm font-bold text-white bg-gradient-to-r from-[#ff6f61] to-[#ff5747] hover:from-[#ff5747] hover:to-[#ff3d2b] rounded-2xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-1.5 hover:-translate-y-0.5 active:translate-y-0 select-none"
                >
                  <span>Daftar via Zoom</span>
                  <ArrowUpRight className="w-4 h-4 shrink-0" />
                </a>
              )}
              {isRegistered ? (
                <>
                  <button
                    onClick={() => onCancelRSVP(event.id)}
                    className="px-5 py-3 text-sm font-semibold text-rose-500 hover:text-rose-600 bg-rose-50 hover:bg-rose-100/80 rounded-2xl transition-colors shrink-0"
                  >
                    Cancel RSVP
                  </button>
                  <div className="hidden md:flex items-center gap-1 text-xs font-bold text-emerald-600 bg-emerald-50 border border-emerald-100 px-3 py-2 rounded-xl">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Seat Reserved</span>
                  </div>
                </>
              ) : (
                <button
                  onClick={() => onRSVP(event.id)}
                  className="px-7 py-3 text-sm font-bold text-white bg-indigo-950 hover:bg-indigo-900 rounded-2xl shadow-md hover:shadow-lg transition-all hover:-translate-y-0.5 active:translate-y-0"
                >
                  Add to My Calendar
                </button>
              )}
            </div>
          </div>

          {/* Grid setup for Desc & Speaker */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Description details */}
            <div className="md:col-span-2 space-y-5">
              <h3 className="font-display font-bold text-lg text-indigo-950">
                About the Event
              </h3>
              <p className="text-indigo-950/80 leading-relaxed text-sm whitespace-pre-line">
                {event.description}
              </p>

              {event.contactNumber && (
                <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100/60 flex items-center gap-3">
                  <span className="p-2 bg-indigo-100 rounded-xl text-indigo-600 font-bold text-xs shrink-0 select-none">📞 CONTACT INFO</span>
                  <p className="text-xs font-semibold text-indigo-950">
                    Informasi & Kontak Pendaftaran: <span className="text-[#ff6f61] font-bold">{event.contactNumber}</span>
                  </p>
                </div>
              )}

              {/* What will receive highlight section */}
              <div className="pt-4 border-t border-indigo-50">
                <h4 className="text-xs font-bold uppercase text-indigo-950/40 tracking-wider mb-2">
                  Session Specifications
                </h4>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-medium text-indigo-950/70">
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-[#ff6f61] rounded-full shrink-0" />
                    ISO 9001:2015, API Q1/Q2, & ASME
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-[#ff6f61] rounded-full shrink-0" />
                    PMI Quality Management
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-[#ff6f61] rounded-full shrink-0" />
                    Welding Continuous Improvement
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-[#ff6f61] rounded-full shrink-0" />
                    Risk-Based Thinking (RBT)
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-[#ff6f61] rounded-full shrink-0" />
                    AI for Quality Management
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 bg-[#ff6f61] rounded-full shrink-0" />
                    ExxonMobil, BP, Freeport Case Studies
                  </li>
                </ul>
              </div>
            </div>

            {/* Presenter Profiles */}
            <div className="space-y-4">
              <h3 className="font-display font-bold text-lg text-indigo-950">
                {event.coSpeaker ? "Narasumber" : "Presenter"}
              </h3>
              
              <div className="space-y-4">
                {/* Speaker 1 */}
                <div className="p-4 border border-white/50 bg-white/40 backdrop-blur-md rounded-2xl flex flex-col items-center text-center">
                  <img
                    src={event.speaker.avatar}
                    alt={event.speaker.name}
                    referrerPolicy="no-referrer"
                    className="w-16 h-16 rounded-full object-cover mb-2.5 ring-4 ring-white shadow-md"
                  />
                  <h4 className="font-bold text-indigo-950 text-xs leading-snug">{event.speaker.name}</h4>
                  <p className="text-[11px] font-semibold text-[#ff6f61] mb-0.5">{event.speaker.title}</p>
                  <p className="text-[9px] text-indigo-950/50 uppercase tracking-widest font-bold mb-2">{event.speaker.company}</p>
                  <p className="text-[11px] text-indigo-950/70 leading-relaxed line-clamp-3">
                    {event.speaker.bio}
                  </p>
                </div>

                {/* Co Speaker if present */}
                {event.coSpeaker && (
                  <div className="p-4 border border-white/50 bg-white/40 backdrop-blur-md rounded-2xl flex flex-col items-center text-center">
                    <img
                      src={event.coSpeaker.avatar}
                      alt={event.coSpeaker.name}
                      referrerPolicy="no-referrer"
                      className="w-16 h-16 rounded-full object-cover mb-2.5 ring-4 ring-white shadow-md"
                    />
                    <h4 className="font-bold text-indigo-950 text-xs leading-snug">{event.coSpeaker.name}</h4>
                    <p className="text-[11px] font-semibold text-[#ff6f61] mb-0.5">{event.coSpeaker.title}</p>
                    <p className="text-[9px] text-indigo-950/50 uppercase tracking-widest font-bold mb-2">{event.coSpeaker.company}</p>
                    <p className="text-[11px] text-indigo-950/70 leading-relaxed line-clamp-3">
                      {event.coSpeaker.bio}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Interactive Q&A / Panel Discussion Board */}
          <div className="pt-6 border-t border-indigo-50 space-y-4">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-indigo-950" />
              <h3 className="font-display font-bold text-lg text-indigo-950">
                Community Discussion Board ({event.comments.length})
              </h3>
            </div>

            {/* New Comment Submission Form */}
            <form onSubmit={handlePostComment} className="flex gap-3">
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                referrerPolicy="no-referrer"
                className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-50"
              />
              <div className="flex-1 relative">
                <input
                  type="text"
                  placeholder="Ask a question or share your excitement..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="w-full pl-4 pr-12 py-2.5 rounded-2xl bg-[#f8f9fe]/60 border border-white/50 backdrop-blur-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 text-sm placeholder:text-indigo-900/40 text-indigo-950"
                />
                <button
                  type="submit"
                  disabled={!commentText.trim()}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1.5 rounded-xl bg-indigo-950 text-white hover:bg-indigo-900 disabled:opacity-40 disabled:hover:bg-indigo-950 transition-all flex items-center justify-center"
                  title="Send message"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>

            {/* Existing Comments List */}
            <div className="space-y-4 max-h-[250px] overflow-y-auto pr-2 pt-2">
              {event.comments.length === 0 ? (
                <div className="text-center py-6 border border-dashed border-indigo-100 rounded-2xl bg-indigo-50/10">
                  <p className="text-xs font-semibold text-indigo-900/40">Be the first to say something in discussion!</p>
                </div>
              ) : (
                event.comments.map((comment) => (
                  <div key={comment.id} className="flex gap-3 items-start p-3 rounded-2xl bg-white/40 border border-white/50 backdrop-blur-sm">
                    <img
                      src={comment.authorAvatar}
                      alt={comment.authorName}
                      referrerPolicy="no-referrer"
                      className="w-9 h-9 rounded-full object-cover shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-1 gap-1">
                        <div className="flex items-baseline gap-1.5 flex-wrap">
                          <span className="font-bold text-xs text-indigo-950">{comment.authorName}</span>
                          <span className="text-[10px] text-indigo-950/40 truncate max-w-[200px]">{comment.authorTitle}</span>
                        </div>
                        <span className="text-[9px] text-indigo-950/35 self-start sm:self-center shrink-0">{comment.timestamp}</span>
                      </div>
                      <p className="text-xs text-indigo-950/80 leading-relaxed pr-2">
                        {comment.content}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>

          </div>

        </div>

        {/* Sticky modal footer summary */}
        <div className="p-4 bg-slate-50 border-t border-indigo-50 text-indigo-950/40 text-[10px] uppercase tracking-wider font-bold text-center shrink-0">
          📍 Community Events Portal secure registration panel
        </div>
      </div>
    </div>
  );
}
