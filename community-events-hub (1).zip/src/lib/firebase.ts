import { initializeApp } from "firebase/app";
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  signOut,
  onAuthStateChanged,
  User
} from "firebase/auth";
import { 
  getFirestore, 
  collection, 
  getDocs, 
  doc, 
  setDoc, 
  getDoc,
  updateDoc,
  arrayUnion,
  query,
  orderBy,
  where,
  addDoc,
  deleteDoc
} from "firebase/firestore";

// Read from config file directly
const firebaseConfig = {
  apiKey: "AIzaSyBdQZ00szebljmH-1f5NuQUUVaH-cZw_nA",
  authDomain: "eternal-age-r3n78.firebaseapp.com",
  projectId: "eternal-age-r3n78",
  storageBucket: "eternal-age-r3n78.firebasestorage.app",
  messagingSenderId: "99015067027",
  appId: "1:99015067027:web:08c89bc065264e6e10d466",
  databaseId: "ai-studio-c0f19f03-64e2-4b21-95ec-b87cf3e14487"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app, "ai-studio-c0f19f03-64e2-4b21-95ec-b87cf3e14487");
export const googleProvider = new GoogleAuthProvider();

// Google Auth Providers Settings
googleProvider.setCustomParameters({
  prompt: "select_account"
});

// Configure scopes for Workspace integrations
googleProvider.addScope("https://www.googleapis.com/auth/calendar");
googleProvider.addScope("https://www.googleapis.com/auth/spreadsheets");
googleProvider.addScope("https://www.googleapis.com/auth/gmail.modify");

export interface FirebaseEvent {
  id: string;
  title: string;
  description: string;
  category: string;
  date: string;
  time: string;
  location: string;
  coverGradient: string;
  speaker: {
    id: string;
    name: string;
    title: string;
    company: string;
    avatar: string;
    bio: string;
    twitter?: string;
    linkedin?: string;
    github?: string;
  };
  rsvpCount: number;
  capacity: number;
  comments: any[];
}

// Global Energy community seeded events
export const ENERGY_SEED_EVENTS: Omit<FirebaseEvent, "id">[] = [];

// Seeding function to initialize/reset Firestore and start empty
export async function seedEventsIfEmpty() {
  try {
    const configDocRef = doc(db, "system_config", "seeding_status");
    const configSnap = await getDoc(configDocRef);
    
    // If we have not performed the clean reset yet, or if it already exists, let's make sure
    // the collection is completely clean/purged of default pre-seeded events.
    const eventsCol = collection(db, "energy_events");
    const snapshot = await getDocs(eventsCol);
    if (!snapshot.empty) {
      // Find events that are from the old initial seed set (or any existing ones, for complete reset)
      const seededTitles = [
        "Deep Water Subsea Pipelines: Extreme Design & Logistics",
        "100MW+ Solar Farm Grid Integration & BESS Strategy",
        "Green Hydrogen: Subsurface Geothermal-Hybrid Storage ROI",
        "PPA Contracting & Energy Risk Hedging in Volatile Markets",
        "Deploying ESG Compliance Frameworks in Gas Mega-Projects"
      ];
      const deletePromises = snapshot.docs
        .filter(docSnap => {
          const data = docSnap.data();
          return seededTitles.includes(data.title) || !data.title;
        })
        .map(docSnap => deleteDoc(doc(db, "energy_events", docSnap.id)));
      
      if (deletePromises.length > 0) {
        await Promise.all(deletePromises);
        console.log("Cleared old default upcoming events from Firestore database.");
      }
    }
    
    // Save state in DB to mark first seed/purge as complete
    await setDoc(configDocRef, { seeded: true, timestamp: new Date().toISOString() });
  } catch (err) {
    console.error("Failed to seed/purge events in Firestore:", err);
  }
}
