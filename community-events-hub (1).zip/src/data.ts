import { Event, Speaker, UserProfile } from "./types";

// Helper to get future date strings dynamically so the countdowns are always alive and interesting
export function getFutureDateString(daysAhead: number): string {
  const date = new Date();
  date.setDate(date.getDate() + daysAhead);
  return date.toISOString().split("T")[0];
}

const tavipAvatar = new URL("./assets/images/tavip_sunandar_1781952368808.jpg", import.meta.url).href;

export const INITIAL_SPEAKERS: Speaker[] = [
  {
    id: "spk-anita",
    name: "Ir. Anita Juliawatri, MT, IWE",
    title: "Senior Quality Professional",
    company: "IOGC",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80",
    bio: "Senior Quality Professional di IOGC dengan kepakaran mendalam di bidang sistem mutu, pengelasan (welding), standardisasi industri hulu-hilir, dan continuous improvement berkelanjutan."
  },
  {
    id: "spk-tavip",
    name: "Ir. M. Tavip Sunandar, MM, IPMO-P, PMP, AIICD",
    title: "Senior Quality Manager – Ex BP",
    company: "Global Energy Project Suite",
    avatar: tavipAvatar,
    bio: "Managing Director & Co-Founder Global Energy Project Suite dengan rekam kepemimpinan legendaris puluhan tahun memimpin portofolio mega-proyek energi hulu-hilir berskala global."
  }
];

export const INITIAL_EVENTS: Event[] = [
  {
    id: "evt-qm-webinar",
    title: "Quality Management Excellence for Project & Operations",
    description: `Saatnya upgrade insight Anda bersama para praktisi industri dalam webinar:

“Quality Management Excellence for Project & Operations”

Diselenggarakan oleh Global Energy Project Professional (GEPP) berkolaborasi dengan Ikatan Ahli Manajemen Proyek Indonesia (IAMPI), webinar ini akan membahas bagaimana quality management, operational excellence, dan transformasi digital berbasis AI dapat meningkatkan kinerja organisasi.

Materi webinar yang akan dibahas mendalam:
✅ ISO 9001:2015, API Q1/API Q2, & ASME Standards
✅ PMI Quality Management
✅ Welding Continuous Improvement
✅ Risk-Based Thinking
✅ AI for Quality Management & Digital Transformation
✅ Lesson learned dari BP, Freeport, dan berbagai EOC industri global

Jangan hanya mengikuti perkembangan industri — jadilah bagian dari profesional yang siap meningkatkan standar kualitas.`,
    category: "ESG & Policy",
    date: "2026-06-27",
    time: "09:00",
    location: "Online via Zoom Meeting",
    coverGradient: "from-indigo-600 via-indigo-950 to-[#ff6f61]",
    speaker: INITIAL_SPEAKERS[0],
    coSpeaker: INITIAL_SPEAKERS[1],
    rsvpCount: 142,
    capacity: 500,
    comments: [],
    registrationLink: "https://bit.ly/Webinarqualitymanagement",
    contactNumber: "0895703094890"
  }
];

export const AVAILABLE_INTERESTS = [
  "Solar Infrastructure", "Subsea Pipelines", "Hydrogen Fuels", "ESG Compliance",
  "PPA Structuring", "Carbon Capture (CCUS)", "Project Finance", "Grid Stability",
  "Geothermal Systems", "Methane Audit", "Hydrocarbons", "Risk Hedging"
];

export const DEFAULT_PROFILE: UserProfile = {
  name: "Ardiansyah Gani",
  title: "Senior Energy Project Lead",
  company: "Equinor",
  bio: "Over 12 years coordinating offshore wind grids and hybrid gas storage projects. Active advocate for professional standardizations, ESG-compliance, and mentorship for junior energy planners.",
  avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80",
  email: "ardigans7017@gmail.com",
  twitter: "ardigans_energy",
  linkedin: "ardiansyah-gani",
  interests: ["Solar Infrastructure", "Hydrogen Fuels", "ESG Compliance", "Project Finance", "Carbon Capture (CCUS)"]
};

// Storage keys
const STORAGE_EVENTS_KEY = "comm_hub_events";
const STORAGE_PROFILE_KEY = "comm_hub_profile";
const STORAGE_MY_RSVPS_KEY = "comm_hub_user_rsvps";

export function loadEvents(): Event[] {
  try {
    const saved = localStorage.getItem(STORAGE_EVENTS_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed && Array.isArray(parsed) && parsed.length > 0 && parsed.some(e => e.id === "evt-qm-webinar")) {
        return parsed;
      }
    }
  } catch (e) {
    console.error("Failed to load events from storage:", e);
  }
  return INITIAL_EVENTS;
}

export function saveEvents(events: Event[]): void {
  try {
    localStorage.setItem(STORAGE_EVENTS_KEY, JSON.stringify(events));
  } catch (e) {
    console.error("Failed to save events to storage:", e);
  }
}

export function loadProfile(): UserProfile {
  try {
    const saved = localStorage.getItem(STORAGE_PROFILE_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error("Failed to load profile from storage:", e);
  }
  return DEFAULT_PROFILE;
}

export function saveProfile(profile: UserProfile): void {
  try {
    localStorage.setItem(STORAGE_PROFILE_KEY, JSON.stringify(profile));
  } catch (e) {
    console.error("Failed to save profile to storage:", e);
  }
}

export function loadUserRSVPs(): string[] {
  try {
    const saved = localStorage.getItem(STORAGE_MY_RSVPS_KEY);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.error("Failed to load RSVPs from storage:", e);
  }
  return [];
}

export function saveUserRSVPs(rsvps: string[]): void {
  try {
    localStorage.setItem(STORAGE_MY_RSVPS_KEY, JSON.stringify(rsvps));
  } catch (e) {
    console.error("Failed to save RSVPs to storage:", e);
  }
}
