/**
 * Types for the Community Events Hub
 */

export interface Speaker {
  id: string;
  name: string;
  title: string;
  company: string;
  avatar: string;
  bio: string;
  twitter?: string;
  github?: string;
  linkedin?: string;
}

export interface Comment {
  id: string;
  authorName: string;
  authorAvatar: string;
  authorTitle?: string;
  content: string;
  timestamp: string;
}

export interface Event {
  id: string;
  title: string;
  description: string;
  category: string; // 'tech' | 'design' | 'product' | 'marketing' | 'wellness' | 'social'
  date: string; // YYYY-MM-DD format
  time: string; // e.g. "18:30"
  location: string; // Virtual (e.g. "Zoom & Discord") or Physical (e.g. "San Francisco Tech Hub")
  coverGradient: string; // CSS gradient class
  speaker: Speaker;
  coSpeaker?: Speaker;
  rsvpCount: number;
  capacity?: number;
  comments: Comment[];
  hostName?: string;
  registrationLink?: string;
  contactNumber?: string;
}

export interface UserProfile {
  name: string;
  title: string;
  company: string;
  bio: string;
  avatar: string;
  email: string;
  twitter?: string;
  github?: string;
  linkedin?: string;
  interests: string[];
}
