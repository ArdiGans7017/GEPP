import React, { useState, useEffect } from "react";
import { Event, Speaker, UserProfile } from "./types";
import { 
  INITIAL_SPEAKERS, 
  INITIAL_EVENTS,
  loadEvents,
  saveEvents,
  loadUserRSVPs,
  saveUserRSVPs,
  DEFAULT_PROFILE
} from "./data";
import EventCard from "./components/EventCard";
import SpeakerCard from "./components/SpeakerCard";
import EventDetailModal from "./components/EventDetailModal";

const tavipAvatar = new URL("./assets/images/tavip_sunandar_1781952368808.jpg", import.meta.url).href;
import { GlobalEnergyLogo } from "./components/GlobalEnergyLogo";
import {
  Compass,
  Users,
  Search,
  CheckCircle2,
  Calendar,
  Sparkles,
  ArrowRight,
  Bell
} from "lucide-react";

export default function App() {
  // Navigation & Page State
  const [activeTab, setActiveTab] = useState<"explore" | "organization">("explore");

  // Core offline states
  const [currentUser] = useState<UserProfile>(DEFAULT_PROFILE);
  const [myRSVPs, setMyRSVPs] = useState<string[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [speakers] = useState<Speaker[]>(INITIAL_SPEAKERS);

  // Search, filtration & query controls
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  // Dialog / Modal Visibility triggers
  const [selectedEvent, setSelectedEvent] = useState<Event | null>(null);

  // Success Toast system for feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Trigger positive toast notification
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Load initial data from localStorage or default
  useEffect(() => {
    let savedEvents = loadEvents();
    if (!savedEvents || savedEvents.length === 0) {
      savedEvents = INITIAL_EVENTS;
      saveEvents(INITIAL_EVENTS);
    }
    setEvents(savedEvents);

    const savedRSVPs = loadUserRSVPs();
    setMyRSVPs(savedRSVPs);
  }, []);

  // RSVP Trigger logic
  const handleRSVP = (eventId: string) => {
    if (myRSVPs.includes(eventId)) return;

    const updatedRSVPs = [...myRSVPs, eventId];
    setMyRSVPs(updatedRSVPs);
    saveUserRSVPs(updatedRSVPs);

    const updatedEvents = events.map((evt) => {
      if (evt.id === eventId) {
        return { ...evt, rsvpCount: (evt.rsvpCount || 0) + 1 };
      }
      return evt;
    });
    setEvents(updatedEvents);
    saveEvents(updatedEvents);

    // Update selectedEvent if it is open
    if (selectedEvent && selectedEvent.id === eventId) {
      setSelectedEvent({ ...selectedEvent, rsvpCount: (selectedEvent.rsvpCount || 0) + 1 });
    }

    const matched = events.find((e) => e.id === eventId);
    triggerToast(`🎉 RSVP Reserved for "${matched?.title}"! Seat secured.`);
  };

  const handleQuickRSVP = (eventId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    handleRSVP(eventId);
  };

  const handleCancelRSVP = (eventId: string) => {
    const updatedRSVPs = myRSVPs.filter((id) => id !== eventId);
    setMyRSVPs(updatedRSVPs);
    saveUserRSVPs(updatedRSVPs);

    const updatedEvents = events.map((evt) => {
      if (evt.id === eventId) {
        return { ...evt, rsvpCount: Math.max(0, (evt.rsvpCount || 0) - 1) };
      }
      return evt;
    });
    setEvents(updatedEvents);
    saveEvents(updatedEvents);

    if (selectedEvent && selectedEvent.id === eventId) {
      setSelectedEvent({ ...selectedEvent, rsvpCount: Math.max(0, (selectedEvent.rsvpCount || 0) - 1) });
    }

    triggerToast("👋 Cancelled reservation. Your seat is released.");
  };

  // Writing comment on Q&A discussions
  const handleAddComment = (eventId: string, comment: any) => {
    const updatedEvents = events.map((evt) => {
      if (evt.id === eventId) {
        const updatedComments = [comment, ...evt.comments];
        return { ...evt, comments: updatedComments };
      }
      return evt;
    });
    setEvents(updatedEvents);
    saveEvents(updatedEvents);

    if (selectedEvent && selectedEvent.id === eventId) {
      setSelectedEvent({ ...selectedEvent, comments: [comment, ...(selectedEvent.comments || [])] });
    }
  };

  // Triggering speaker-session filter across routes
  const handleViewSpeakerSessions = (speakerId: string) => {
    const target = speakers.find(s => s.id === speakerId);
    if (!target) return;
    setSearchQuery(target.name);
    setSelectedCategory("All");
    setActiveTab("explore");
    triggerToast(`🔍 Filtering sessions featuring "${target.name}"`);
  };

  // Core Events filtration calculations
  const filteredEvents = events.filter((evt) => {
    const matchesSearch =
      evt.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evt.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      evt.speaker.name.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCategory =
      selectedCategory === "All" ||
      evt.category.toLowerCase() === selectedCategory.toLowerCase();

    return matchesSearch && matchesCategory;
  });

  const categories = ["All", "Renewables", "Hydrocarbons", "Future Fuels", "ESG & Policy", "Economics"];

  // Fetch full Event objects matching user RSVPs for Dashboard preview
  const verifiedMyEvents = events.filter((evt) => myRSVPs.includes(evt.id));

  const displayName = currentUser.name || "Active Member";
  const displayAvatar = currentUser.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80";

  // Authenticated Screen Rendering
  return (
    <div className="min-h-screen bg-[#F8F9FE] flex flex-col justify-between font-sans relative overflow-hidden">

      {/* Decorative background glass spotlight blobs */}
      <div className="absolute top-[-100px] right-[-100px] w-[500px] h-[500px] bg-indigo-500 opacity-10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-[30%] left-[-150px] w-[450px] h-[450px] bg-[#ff6f61] opacity-[0.08] rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[10%] right-[-100px] w-[550px] h-[550px] bg-indigo-600 opacity-[0.07] rounded-full blur-[140px] pointer-events-none" />

      {/* Toast popup */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-fade-in pointer-events-auto">
          <div className="flex items-center gap-3 px-5 py-4 bg-indigo-950/90 text-white border border-white/20 rounded-2xl shadow-2xl backdrop-blur-md">
            <CheckCircle2 className="w-5 h-5 text-[#ff6f61] shrink-0" />
            <p className="text-xs font-bold leading-normal">{toastMessage}</p>
          </div>
        </div>
      )}

      {/* Top Banner Navigation */}
      <nav className="sticky top-0 z-40 bg-white/35 backdrop-blur-xl border-b border-white/50 shrink-0 select-none shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">

            {/* Logo brand */}
            <div
              className="flex items-center gap-2.5 cursor-pointer hover:opacity-90 transition-opacity"
              onClick={() => {
                setActiveTab("explore");
                setSearchQuery("");
                setSelectedCategory("All");
              }}
            >
              <GlobalEnergyLogo size="sm" layout="horizontal" />
            </div>

            {/* Middle Nav Tabs */}
            <div className="hidden md:flex items-center gap-1 bg-white/40 border border-white/50 p-1 rounded-xl backdrop-blur-md">
              <button
                id="tab-btn-explore"
                onClick={() => setActiveTab("explore")}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                  activeTab === "explore"
                    ? "bg-white/70 text-indigo-950 shadow-sm backdrop-blur-md"
                    : "text-indigo-900/60 hover:text-indigo-950 hover:bg-white/10"
                }`}
              >
                <Compass className="w-4 h-4" />
                <span>Explore Live Hub</span>
              </button>
              <button
                id="tab-btn-organization"
                onClick={() => setActiveTab("organization")}
                className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                  activeTab === "organization"
                    ? "bg-white/70 text-indigo-950 shadow-sm backdrop-blur-md"
                    : "text-indigo-900/60 hover:text-indigo-950 hover:bg-white/10"
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Organization</span>
              </button>
            </div>

            {/* Quick Action */}
            <div className="flex items-center gap-4">
              {/* Profile indicator removed as requested */}
            </div>

          </div>
        </div>
      </nav>

      {/* Main Grid Content */}
      <main className="flex-grow select-none">

        {activeTab === "explore" && (
          <div className="animate-fade-in">
            {/* Dynamic Hero Showcase Section */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 md:pt-12">
              <div className="relative overflow-hidden bg-white/40 backdrop-blur-2xl border border-white/50 rounded-[32px] shadow-2xl p-8 md:p-14 lg:p-20 text-center select-none text-indigo-950">
                {/* Absolutes and meshes */}
                <div className="absolute inset-x-0 bottom-0 top-0 bg-gradient-to-tr from-[#ff6f61]/10 via-indigo-200/5 to-transparent rounded-[32px] pointer-events-none" />
                <div className="absolute top-1/2 left-1/4 w-72 h-72 bg-gradient-to-tr from-[#ff6f61]/15 to-transparent rounded-full blur-3xl pointer-events-none" />
                <div className="absolute -bottom-10 right-10 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

                <div className="max-w-4xl mx-auto space-y-6 relative flex flex-col items-center">

                  {/* Big Custom Brand Emblem with the reference design */}
                  <GlobalEnergyLogo size="lg" showText={false} className="mb-2" />

                  {/* Micro-badge */}
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/60 text-indigo-950/75 text-xs font-extrabold uppercase tracking-widest border border-white/80 mx-auto backdrop-blur-md shadow-sm">
                    <Sparkles className="w-3.5 h-3.5 text-[#ff6f61] animate-pulse" />
                    <span>Verified Professional Resident Network</span>
                  </div>

                  <h1 className="font-display font-extrabold text-4xl sm:text-5xl md:text-6xl tracking-tight leading-tight max-w-[95%] mx-auto text-indigo-950">
                    Empowering Global <br />
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-700 via-indigo-950 to-[#ff6f61] leading-normal block uppercase font-serif">Energy Pioneers</span>
                  </h1>

                  <p className="max-w-3xl mx-auto text-indigo-950/75 text-sm md:text-base leading-relaxed">
                    Selamat datang di rumah bagi para inovator energi. Global Energy Project Professional Community adalah wadah kolaborasi lintas negara yang menyatukan para insinyur, manajer proyek, dan pembuat kebijakan. Di sini, kami berbagi wawasan industri terbaru, mendiskusikan solusi energi berkelanjutan, dan membuka akses ke peluang karir global terbaik. Bersama kita mendorong transisi energi yang lebih bersih dan efisien.
                  </p>

                  {/* Actions banner */}
                  <div className="pt-6 flex flex-wrap items-center justify-center gap-3">
                    <button
                      onClick={() => {
                        const el = document.getElementById("upcoming-hub-listing");
                        el?.scrollIntoView({ behavior: "smooth" });
                      }}
                      className="px-6 py-3 rounded-2xl text-xs font-bold bg-[#ff6f61] text-white hover:bg-[#ff5747] transition-all shadow-md hover:shadow-lg flex items-center gap-1 hover:-translate-y-0.5"
                    >
                      <span>Browse Scheduled Events</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setActiveTab("organization")}
                      className="px-6 py-3 rounded-2xl text-xs font-bold bg-white/60 text-indigo-950 hover:bg-white/80 transition-all border border-white/60"
                    >
                      Explore Organization
                    </button>
                  </div>

                </div>
              </div>
            </section>

            {/* Main Interactive Directory Section */}
            <section id="upcoming-hub-listing" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-8 select-none">

              {/* Filter controls panel */}
              <div className="flex flex-col md:flex-row md:items-end justify-between gap-5 border-b border-indigo-50 pb-6">
                <div>
                  <h2 className="font-display font-black text-2xl lg:text-3xl text-indigo-950">
                    Live Upcoming Actions
                  </h2>
                  <p className="text-sm text-indigo-900/50">Filter upcoming calendar countdowns or search by title coordinates</p>
                </div>

                {/* Filter and Search box */}
                <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
                  <div className="relative w-full sm:w-64">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3.5">
                      <Search className="w-4 h-4 text-indigo-900/35" />
                    </span>
                    <input
                      type="text"
                      placeholder="Search live events..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 text-xs font-medium rounded-xl border border-indigo-100 bg-white focus:outline-none focus:border-indigo-500 placeholder:text-indigo-900/35 text-indigo-950"
                    />
                  </div>


                </div>
              </div>

              {/* Category selector pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
                {categories.map((cat) => {
                  const isSelected = selectedCategory === cat;
                  return (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-4.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                        isSelected
                          ? "bg-indigo-950 text-white shadow-sm"
                          : "bg-indigo-50/50 text-indigo-950 hover:bg-indigo-50 border border-indigo-100/40"
                      }`}
                    >
                      {cat}
                    </button>
                  );
                })}
              </div>

              {/* Grid showcasing filtered cards */}
              {filteredEvents.length === 0 ? (
                <div className="text-center py-16 border-2 border-dashed border-indigo-50 rounded-3xl bg-indigo-50/10">
                  <Bell className="w-10 h-10 text-indigo-300 mx-auto mb-3 animate-bounce" />
                  <p className="text-base font-bold text-indigo-950">No upcoming events match coordinates</p>
                  <p className="text-xs text-indigo-900/40 max-w-sm mx-auto mt-1">
                    Try adjusting your search criteria, selecting another category, or host the session under your name!
                  </p>
                  <button
                    onClick={() => {
                      setSearchQuery("");
                      setSelectedCategory("All");
                    }}
                    className="mt-4 text-xs font-bold text-[#ff6f61] hover:underline"
                  >
                    Reset Filter Parameters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredEvents.map((evt) => (
                    <EventCard
                      key={evt.id}
                      event={evt}
                      isRegistered={myRSVPs.includes(evt.id)}
                      onSelect={(e) => setSelectedEvent(e)}
                      onQuickRSVP={handleQuickRSVP}
                    />
                  ))}
                </div>
              )}
            </section>
          </div>
        )}
        {/* View tab: Organization details */}
        {activeTab === "organization" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-12 animate-fade-in select-none">
            
            <div className="border-b border-indigo-50 pb-6 text-center md:text-left">
              <h2 className="font-display font-black text-2xl lg:text-3xl text-indigo-950 tracking-tight font-serif uppercase">
                Organization Structure
              </h2>
              <p className="text-sm text-indigo-900/50">Core Leadership, Advisory Administration, and Strategic Governance</p>
            </div>

            {/* Owner Section Card with custom generated profile photo */}
            <div className="bg-white/50 border border-white/60 rounded-[32px] p-8 md:p-12 shadow-xl backdrop-blur-3xl relative overflow-hidden max-w-4xl mx-auto">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-[#ff6f61]/10 to-transparent rounded-bl-full pointer-events-none" />
              <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

              <div className="flex flex-col md:flex-row gap-8 items-center md:items-start relative">
                
                {/* Image Frame */}
                <div className="relative shrink-0 group">
                  <div className="absolute -inset-1 rounded-3xl bg-gradient-to-tr from-[#ff6f61] via-indigo-600 to-amber-300 blur opacity-25 group-hover:opacity-45 transition duration-300 pointer-events-none" />
                  <img
                    src={tavipAvatar}
                    alt="M. Tavip Sunandar"
                    referrerPolicy="no-referrer"
                    className="relative w-48 h-48 md:w-56 md:h-56 rounded-3xl object-cover ring-4 ring-white/85 shadow-2xl transition duration-300 group-hover:scale-[1.02]"
                  />
                  <span className="absolute bottom-3 left-1/2 -translate-x-1/2 bg-indigo-950/90 backdrop-blur-md text-white text-[10px] font-extrabold px-3 py-1 rounded-lg uppercase tracking-wider shadow-md">
                    Owner
                  </span>
                </div>

                {/* Professional Info details */}
                <div className="flex-1 space-y-5 text-center md:text-left">
                  <div className="space-y-2">
                    <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#ff6f61] bg-[#ff6f61]/5 border border-[#ff6f61]/15 px-2.5 py-1 rounded-full">
                      Leader Profile
                    </span>
                    <h3 className="font-display font-black text-2xl sm:text-3xl text-indigo-950 pt-1.5 leading-none">
                      M. Tavip Sunandar
                    </h3>
                    <p className="text-xs sm:text-sm font-extrabold text-[#ff6f61] pt-1">
                      Senior Director of Projects - Lead Consultant - Project Management and PMO -Ex BP
                    </p>
                    <p className="text-[11px] font-bold text-indigo-900/40">
                      Managing Director & Co-Founder, Global Energy Project Suite
                    </p>
                  </div>

                  {/* Profile Description */}
                  <p className="text-xs sm:text-sm text-indigo-950/75 leading-relaxed font-normal">
                    M. Tavip Sunandar memimpin tata kelola organisasi Komunitas Profesional Global Energy Project dengan pengalaman legendaris puluhan tahun memimpin portofolio mega-proyek berskala global. Sebagai mantan kontributor senior di British Petroleum (Ex-BP) dan konsultan pemimpin kawakan, beliau berdedikasi menciptakan standar emas dalam Project Management and pembentukan Project Management Officer (PMO) berdaya guna tinggi guna memuluskan dekarbonisasi infrastruktur energi global.
                  </p>

                  {/* Core Value Pillars / Credentials List */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    <div className="bg-white/70 border border-indigo-50/50 p-4 rounded-2xl shadow-sm text-left">
                      <p className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                        <span>🌍</span>
                        <span>Global Experience</span>
                      </p>
                      <p className="text-[10.5px] text-indigo-900/50 mt-1 leading-normal">Mantan Kontributor Senior British Petroleum (Ex BP) dengan rekam jejak mega-proyek laut dalam.</p>
                    </div>
                    <div className="bg-white/70 border border-indigo-50/50 p-4 rounded-2xl shadow-sm text-left">
                      <p className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                        <span>📋</span>
                        <span>PMO & Project Management</span>
                      </p>
                      <p className="text-[10.5px] text-indigo-900/50 mt-1 leading-normal">Pemantapan tata kelola proyek berisiko ekstrim dan integrasi infrastruktur hulu-hilir.</p>
                    </div>
                  </div>
                </div>

              </div>
            </div>

            {/* Consultation & Advisory Pillars */}
            <div className="max-w-4xl mx-auto space-y-6 pt-4">
              <h4 className="font-display font-bold text-sm text-indigo-900/40 text-center uppercase tracking-widest">
                Our Strategic Consultation Pillars
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div className="bg-white/50 border border-white/60 rounded-2xl p-6 text-center space-y-2.5">
                  <div className="w-10 h-10 rounded-full bg-indigo-50 text-indigo-950 flex items-center justify-center mx-auto text-lg">💡</div>
                  <h5 className="font-bold text-xs text-indigo-950">Project Management Consulting</h5>
                  <p className="text-[11px] text-indigo-900/50 leading-relaxed">Penyelarasan operasional hulu-hilir migas dan energi terbarukan berskala masif dengan audit mitigasi teknis kelas dunia.</p>
                </div>
                <div className="bg-white/50 border border-white/60 rounded-2xl p-6 text-center space-y-2.5">
                  <div className="w-10 h-10 rounded-full bg-[#ff6f61]/5 text-[#ff6f61] flex items-center justify-center mx-auto text-lg">🛠️</div>
                  <h5 className="font-bold text-xs text-indigo-950">Setup & Optimasi PMO</h5>
                  <p className="text-[11px] text-[#indigo-950] leading-relaxed">Menghadirkan tata kelola kantor manajemen proyek (PMO) berdaya tinggi guna optimasi efektivitas biaya dan transparansi waktu.</p>
                </div>
                <div className="bg-white/50 border border-white/60 rounded-2xl p-6 text-center space-y-2.5">
                  <div className="w-10 h-10 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center mx-auto text-lg">⚡</div>
                  <h5 className="font-bold text-xs text-indigo-950">Offshore Energy Integration</h5>
                  <p className="text-[11px] text-indigo-900/50 leading-relaxed">Transfer kepakaran teruji eksklusif untuk pipeline laut dalam (subsea) dan transisi gigawatt-scale energi bersih.</p>
                </div>
              </div>
            </div>

          </div>
        )}

      </main>

      {/* Footer copyright */}
      <footer className="bg-indigo-950 text-indigo-200 border-t border-indigo-900 py-10 mt-16 select-none shrink-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">

            {/* Logo copy */}
            <div className="flex items-center gap-2.5">
              <GlobalEnergyLogo size="sm" layout="horizontal" showText={false} />
              <span className="font-serif font-bold uppercase tracking-wide text-white text-xs">
                GLOBAL ENERGY PROJECT PROFESSIONAL COMMUNITY
              </span>
            </div>

            {/* Quick Links */}
            <div className="flex items-center gap-6 text-xs text-indigo-200/60 font-medium">
              <button onClick={() => { setActiveTab("explore"); window.scrollTo({top: 0, behavior: "smooth"}); }} className="hover:text-white transition-colors cursor-pointer">Calendar</button>
              <button onClick={() => { setActiveTab("organization"); window.scrollTo({top: 0, behavior: "smooth"}); }} className="hover:text-white transition-colors cursor-pointer">Organization</button>
            </div>

          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between border-t border-indigo-900/60 pt-6 text-[11px] text-indigo-200/40 font-mono">
            <p>© 2026 GLOBAL ENERGY PROJECT PROFESSIONAL COMMUNITY. ALL RIGHTS RESERVED.</p>
          </div>
        </div>
      </footer>

      {/* MODALS RENDERING REGISTRY */}

      {/* Event Details and Discussion forum Overlay */}
      {selectedEvent && (
        <EventDetailModal
          event={selectedEvent}
          isRegistered={myRSVPs.includes(selectedEvent.id)}
          currentUser={currentUser}
          onClose={() => setSelectedEvent(null)}
          onRSVP={handleRSVP}
          onCancelRSVP={handleCancelRSVP}
          onAddComment={handleAddComment}
        />
      )}

    </div>
  );
}
